// SIMPLE BOT MANAGER FOR TERMUX
const fs = require('fs');
const path = require('path');

class BotManager {
    constructor() {
        this.botsFile = path.join(__dirname, 'bots.json');
        this.bots = this.loadBots();
    }
    
    loadBots() {
        try {
            return JSON.parse(fs.readFileSync(this.botsFile, 'utf8'));
        } catch {
            return [];
        }
    }
    
    createBot(clientId, chatId) {
        const bot = {
            id: clientId,
            token: this.generateToken(),
            chatId: chatId,
            active: true,
            created: new Date().toISOString()
        };
        
        this.bots.push(bot);
        this.saveBots();
        
        // Create simple bot file
        const botFile = `
const TelegramBot = require('node-telegram-bot-api');
const bot = new TelegramBot('${bot.token}', {polling: true});

bot.on('message', (msg) => {
    console.log(\`[\${new Date().toLocaleString()}] Message from \${msg.chat.id}: \${msg.text}\`);
    
    // Forward to client
    bot.sendMessage('${chatId}', \`📨: \${msg.text}\`);
    
    // Log to admin
    bot.sendMessage('ADMIN_CHAT_ID_HERE', \`[${clientId}] \${msg.text}\`);
});

console.log('🤖 Bot ${clientId} started!');
`;
        
        fs.writeFileSync(path.join(__dirname, `${clientId}_bot.js`), botFile);
        return bot.token;
    }
    
    generateToken() {
        return Math.random().toString(36).substring(2) + 
               Math.random().toString(36).substring(2);
    }
}

module.exports = BotManager;